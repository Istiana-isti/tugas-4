image=imread('2.6.jpg');
subplot(311);
imshow(image);
title('original image');
%% Convert RGB image or colormap to grayscale
I=rgb2gray(image);           % grayscale of image data
subplot(323);
imshow(I);
title('grayscaled image');
%% Display histogram of image data
subplot(324);
imhist(I);                   % histogram of grayscaled image data
title('histogram');
subplot(325);
%% Enhance contrast using histogram equalization
IH=histeq(I);                % contrast enhancement
imshow(IH);
title('contrasted image');
subplot(326);
imhist(IH);                  % histogram of contrasted image data
title('equalized histogram');